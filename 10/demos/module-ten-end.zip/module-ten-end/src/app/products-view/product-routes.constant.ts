export enum PRODUCT_ROUTER_TOKENS {
  DETAIL = 'detail',
  CUSTOMIZE = 'customize',
}
