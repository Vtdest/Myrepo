import { Component } from '@angular/core';

@Component({
  selector: 'app-combo-card-view',
  templateUrl: './combo-card-view.component.html',
  styleUrls: ['./combo-card-view.component.css']
})
export class ComboCardViewComponent {
}
