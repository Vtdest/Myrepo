import { NgModule } from '@angular/core';
import { AboutComponent } from './about.component';

@NgModule({
  declarations: [AboutComponent],
  exports: [AboutComponent]
})
export class AboutModule {}
