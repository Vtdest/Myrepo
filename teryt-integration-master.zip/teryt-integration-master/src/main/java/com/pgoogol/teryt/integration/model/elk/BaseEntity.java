package com.pgoogol.teryt.integration.model.elk;

public interface BaseEntity {

    String getId();

}
